export class Test{
    testId:number;
    testTitle:String;
    testDuration : String;
    testTotalmarks : Test;
    
    

    constructor(){}
}
