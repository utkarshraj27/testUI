import { Test } from './test';


export class User{
    userId:number;
    userName:String;
    isAdmin : boolean;
    userTest : Test;
    userPassword : String;
   
    

    constructor(){}
}
